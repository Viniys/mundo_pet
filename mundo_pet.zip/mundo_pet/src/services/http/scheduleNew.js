import { apiConfig } from "../api-config"

export const scheduleNew = async ({ id, name, petName, telNumber, descriptionValue, when }) => {
    try {
        await fetch(`${apiConfig.baseURL}/schedules`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                id,
                name,
                petName,
                telNumber,
                descriptionValue,
                when
            }),
        })

        alert("Agendamento realizado com sucesso!")
    } catch (e) {
        console.error(e)
    }
}