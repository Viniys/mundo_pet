import { apiConfig } from "../api-config"

export const scheduleCancel = async ({ id }) => {
    try {
        await fetch(`${apiConfig.baseURL}/schedules/${id}`, {
            method: "DELETE"
        })

        alert("Agendamento cancelado com sucesso!")
    } catch (e) {
        console.error(e)
        alert("Não foi possível deletar o agendamento!")
    }
}