const dayjs = require("dayjs")
const { scheduleNew } = require("../../services/http/scheduleNew")

const form = document.querySelector("form")
const pet = document.querySelector("#pet")
const tel = document.querySelector("#tel")
const person = document.querySelector("#person")
const description = document.querySelector("#description")

const time = document.querySelector("#time")
const selectedDate = document.querySelector("#date")
const selectedDateModal = document.querySelector("#dateModal")

const inputToday = dayjs(new Date()).format("YYYY-MM-DD")
const currentTime = dayjs(new Date()).format("HH:mm")

time.value = currentTime
selectedDate.min = inputToday
selectedDate.value = inputToday
selectedDateModal.min = inputToday
selectedDateModal.value = inputToday

form.onsubmit = async (e) => {
    e.preventDefault()

    try {
        const name = person.value
        const petName = pet.value
        const telNumber = tel.value
        const timeValue = time.value
        const descriptionValue = description.value
        const selectedDateModalValue = selectedDateModal.value

        if (!name) {
            return alert("O nome não pode ser vazio!")
        }

        if (!petName) {
            return alert("O nome do pet não pode ser vazio!")
        }

        if (!telNumber) {
            return alert("O telefone não pode ser vazio!")
        }

        if (!descriptionValue) {
            return alert("A descrição não pode ser vazia!")
        }

        if (!timeValue) {
            return alert("A hora não pode ser vazia!")
        }

        if (!selectedDateModalValue) {
            return alert("A data não pode ser vazia!")
        }

        const id = String(new Date().getTime())
        const [hour] = timeValue.split(":")
        const when = dayjs(selectedDateModalValue).add(hour, "hour")

        scheduleNew({
            id,
            name,
            petName,
            telNumber,
            descriptionValue,
            when
        })

        person.value = ""
        pet.value = ""
        tel.value = ""
        description.value = ""

        location.reload()
    } catch (e) {
        alert("Não foi possível realizar o agendamento")
        console.error(e)
    }
}