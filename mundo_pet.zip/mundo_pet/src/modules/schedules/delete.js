import { scheduleCancel } from "../../services/http/scheduleCancel"
import { schedulesDay } from "./load"

const periodTable = document.querySelectorAll(".period-table")

periodTable.forEach((period) => {
    period.addEventListener("click", async (event) => {
        if (event.target.classList.contains("cancel-schedule")) {
            const item = event.target.closest(".table-container")

            if (!item) return

            const id = item.dataset.id

            console.log("ID do agendamento", id)

            if (id) {
                const isConfirm = confirm("Tem certeza que deseja cancelar esse agendamento?");

                if (isConfirm) {
                    try {
                        await scheduleCancel({ id });
                        schedulesDay();
                    } catch (error) {
                        console.error("Erro ao cancelar:", error);
                    }
                }
            }
        }
    })
})