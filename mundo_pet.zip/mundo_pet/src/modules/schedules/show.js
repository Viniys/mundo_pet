import dayjs from "dayjs"

const periodMorning = document.querySelector("#period-morning")
const periodAfternoon = document.querySelector("#period-afternoon")
const periodNight = document.querySelector("#period-night")

export const scheduleShow = async ({ dailySchedules }) => {
    try {
        dailySchedules.map((schedule) => {
            const tableContainer = document.createElement("div")
            tableContainer.classList.add("table-container")

            tableContainer.setAttribute("data-id", schedule.id)

            const table = document.createElement("table")
            const tbody = document.createElement("tbody")
            const tr = document.createElement("tr")

            const td = document.createElement("td")
            const td2 = document.createElement("td")
            td2.innerHTML = `${schedule.petName} <span>/${schedule.name}</span>`
            const td3 = document.createElement("td")
            td3.classList.add("remove")

            const link = document.createElement("a")
            link.target = '_blank';
            link.classList.add("cancel-schedule")
            link.style.textDecoration = 'none';
            link.style.color = 'inherit';

            link.textContent = 'Remover agendamento';

            const strong = document.createElement("strong")
            strong.textContent = dayjs(schedule.when).format("HH:mm")

            table.append(tbody)
            tbody.append(tr)
            tr.append(td, td2, td3)
            td.append(strong)
            td3.append(link)
            tableContainer.append(table)

            const hour = dayjs(schedule.when).hour()

            if (hour <= 12) {
                periodMorning.appendChild(tableContainer)
            } else if (hour >= 12 && hour <= 18) {
                periodAfternoon.appendChild(tableContainer)
            } else {
                periodNight.appendChild(tableContainer)
            }
        })
    } catch (e) {
        console.error(e);
        alert("Não foi possível exibir os agendamentos");
    }
}