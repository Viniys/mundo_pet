import { scheduleFetchByDay } from "../../services/http/schedule-fetch-by-day"
import { scheduleShow } from "./show"

const selectedDate = document.querySelector("#date")
const periodMorning = document.querySelector("#period-morning")
const periodAfternoon = document.querySelector("#period-afternoon")
const periodNight = document.querySelector("#period-night")

export const schedulesDay = async () => {
    periodMorning.innerHTML = ""
    periodAfternoon.innerHTML = ""
    periodNight.innerHTML = ""

    const date = selectedDate.value
    const dailySchedules = await scheduleFetchByDay({ date })
    scheduleShow({ dailySchedules })
}