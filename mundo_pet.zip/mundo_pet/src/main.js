"use strict"

// Config JS
import "./libs/dayjs.js"
import "./libs/flatpicker"

// CSS
import "./styles/footer.css"
import "./styles/header.css"
import "./styles/main.css"
import "./styles/modal.css"
import "./styles/section-grid.css"
import "./styles/section-top.css"
import "./styles/index.css"

// JS
import "./modules/form/submit.js"
import "./modules/page-load.js"
import "./modules/schedules/load.js"
import "./modules/form/data-change.js"
import "./modules/modal/modal-toggle.js"
import "./modules/schedules/delete.js"